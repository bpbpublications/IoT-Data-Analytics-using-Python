import msgpack



# Encoded messagepack data
packed_data = b'\x82\xa6Header\x87\xa2ID\xa8Asset123\xa3SNo\xaaGateway456\xa5AType\x05\xa5DType\x01\xa3UID\xa7Unit789\xa3Ver\xa31.0\xa5Dflag\xab3;1;1;1;100\xa4data\x91\x86\xa3rtc\xb32022-03-01T10:30:00\xa4temp\xcb@9ffffff\xa8pressure\xcb@\x8f\xaa\x00\x00\x00\x00\x00\xaawind_speed\xcb@(\x99\x99\x99\x99\x99\x9a\xa3rpm\xcd\x05\xdc\xadenergy_output\xcd\x03\xe8'

# Decode messagepack data
decoded_data = msgpack.unpackb(packed_data, raw=False)

# Extract values from decoded data
header = decoded_data['Header']
data = decoded_data['data'][0]

# Extract values from header
ID = header['ID']
SNo = header['SNo']
AType = header['AType']
DType = header['DType']
UID = header['UID']
Ver = header['Ver']
Dflag = header['Dflag']

# Extract values from data
rtc = data['rtc']
temp = data['temp']
pressure = data['pressure']
wind_speed = data['wind_speed']
rpm = data['rpm']
energy_output = data['energy_output']

# Print the values
print('ID:', ID)
print('SNo:', SNo)
print('AType:', AType)
print('DType:', DType)
print('UID:', UID)
print('Ver:', Ver)
print('Dflag:', Dflag)
print('RTC:', rtc)
print('Temperature:', temp)
print('Pressure:', pressure)
print('Wind Speed:', wind_speed)
print('RPM:', rpm)
print('Energy Output:', energy_output)
