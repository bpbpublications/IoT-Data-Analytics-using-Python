import fastavro
import io
# Define the schema
schema = {
    "type": "record",
    "name": "SensorData",
    "fields": [
        {"name": "temperature", "type": "float"},
        {"name": "humidity", "type": "float"}
    ]
}
# Read the binary data
binary_data = b'\x00\x01\x06temperature\x02=\x00\x06humidity\x02\x9d\x99\x1a@'
# Create a BytesIO object from the binary data
bytes_io = io.BytesIO(binary_data)
# Deserialize the binary data using the schema
parsed_data = fastavro.schemaless_reader(bytes_io, schema)
# Print the parsed data
print(parsed_data)
