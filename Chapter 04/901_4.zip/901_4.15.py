import pandas as pd
import numpy as np
from scipy.signal import savgol_filter

class DataTransformationEngine:
    def __init__(self):
        pass
    
    def transform_data(self, df):
        # Check if all required columns are present in the DataFrame
        required_cols = ['rtc', 'temp', 'pressure', 'wind_speed', 'rpm', 'energy_output']
        missing_cols = set(required_cols) - set(df.columns)
        if missing_cols:
            raise KeyError(f"{missing_cols} not in index")
        
        # Convert rtc column to datetime format
        df['rtc'] = pd.to_datetime(df['rtc'])
        
        # Group data by hour and calculate mean value for each group
        df = df.set_index('rtc')
        df['wind_speed'] = pd.to_numeric(df['wind_speed'])
        df['temp'] = pd.to_numeric(df['temp'])
        df = df.groupby(pd.Grouper(freq='H')).mean()
        
        
        # Normalize the value column
        df['wind_speed'] = (df['wind_speed'] - df['wind_speed'].mean()) / df['wind_speed'].std()
        df['temp'] = (df['temp'] - df['temp'].mean()) / df['temp'].std()
        
        # Add a column for the weekday
        df['Weekday'] = df.index.weekday
        
        # Apply a Savitzky-Golay filter to the value column
        df['wind_speed'] = savgol_filter(df['wind_speed'], window_length=3, polyorder=2)
        df['temp'] = savgol_filter(df['temp'], window_length=3, polyorder=2)
        
        # Add columns for the hour and minute
        df['Hour'] = df.index.hour
        df['Minute'] = df.index.minute
        
        # Resample the data to 15-minute intervals
        df = df.resample('15T').mean()

        # Remove columns with low variance
        numeric_cols = df.select_dtypes(include=np.number).columns
        variances = df[numeric_cols].var()
        cols_to_drop = variances[variances < 0.01].index
        df = df.drop(cols_to_drop, axis=1)
        
        return df

# Load data from the CSV file
df = pd.read_csv('cleaned_data.csv')

# Initialize the data transformation engine
data_transformer = DataTransformationEngine()

try:
    # Transform the data using the data transformation engine
    transformed_data = data_transformer.transform_data(df)
    
    # Write the transformed data to a CSV file
    transformed_data.to_csv('transformed_data.csv')
    
    print('Transformation complete. Output saved to transformed_data.csv')
except KeyError as e:
    print(f"Error: {e}")
