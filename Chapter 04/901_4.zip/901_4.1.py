import json

# Open the JSON file and read its contents
with open("json_data.json", "r") as file:
    json_data = file.read()

# Parse the JSON data and convert it into a Python dictionary
parsed_data = json.loads(json_data)

# Print the values for the "temperature" and "humidity" keys
print("Temperature: " + str(parsed_data["temperature"]))
print("Humidity: " + str(parsed_data["humidity"]))

