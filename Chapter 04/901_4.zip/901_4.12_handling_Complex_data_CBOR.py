import cbor
import json

# JSON data to be serialized
data = {
    "Header": {
        "ID": "Asset123",
        "SNo": "Gateway456",
        "AType": 5,
        "DType": 1,
        "UID": "Unit789",
        "Ver": "1.0",
        "Dflag": "3;1;1;1;100"
    },
  "data": [
    {
      "rtc": "2022-03-01T10:30:00",
      "temp": 25.4,
      "pressure": 1013.25,
      "wind_speed": 12.3,
      "rpm": 1500,
      "energy_output": 1000
    }
  ]
}

# Convert JSON data to Python object
json_data = json.dumps(data)
py_data = json.loads(json_data)

# Serialize data in CBOR format
serialized_data = cbor.dumps(py_data)

# Print serialized data
print("Serialized data: ", serialized_data)

# Deserialize data from CBOR format
deserialized_data = cbor.loads(serialized_data)

# Print deserialized data
print("Deserialized data: ", deserialized_data)
