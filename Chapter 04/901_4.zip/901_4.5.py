import msgpack

# binary data from the question
binary_data = b'\x82\xabtemperature\xcb@7\x80\x00\x00\x00\x00\x00\xa8humidity\xcb@N\x19\x99\x99\x99\x99\x9a'

# check the length of the binary data
print(len(binary_data))

# unpack the binary data using msgpack with the raw option set to False
unpacked_data = msgpack.unpackb(binary_data, raw=False)

# print the unpacked data
print(unpacked_data)
#Extract the temperature and humidity values
temperature = unpacked_data['temperature']
humidity = unpacked_data['humidity']

# Print the values
print('Temperature:', temperature)
print('Humidity:', humidity)
