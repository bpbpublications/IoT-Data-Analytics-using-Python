import fastavro
from datetime import datetime

# Define the schema for the data
schema = {
    "type": "record",
    "name": "WindTurbineData",
    "fields": [
        {"name": "Header", "type": {
            "type": "record",
            "name": "Header",
            "fields": [
                {"name": "ID", "type": "string"},
                {"name": "SNo", "type": "string"},
                {"name": "AType", "type": "int"},
                {"name": "DType", "type": "int"},
                {"name": "UID", "type": "string"},
                {"name": "Ver", "type": "string"},
                {"name": "Dflag", "type": "string"}
            ]
        }},
        {"name": "data", "type": {"type": "array", "items": {
            "type": "record",
            "name": "SensorData",
            "fields": [
                {"name": "rtc", "type": {"type": "string", "logicalType": "timestamp-millis"}},
                {"name": "temp", "type": "float"},
                {"name": "pressure", "type": "float"},
                {"name": "wind_speed", "type": "float"},
                {"name": "rpm", "type": "int"},
                {"name": "energy_output", "type": "int"}
            ]
        }}}
    ]
}

# Write data to a file in the Avro binary format
data = {
    "Header": {
        "ID": "Asset123",
        "SNo": "Gateway456",
        "AType": 5,
        "DType": 1,
        "UID": "Unit789",
        "Ver": "1.0",
        "Dflag": "3;1;1;1;100"
    },
    "data": [
        {
            "rtc": datetime.fromisoformat("2022-03-01T10:30:00").strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "temp": 25.4,
            "pressure": 1013.25,
            "wind_speed": 12.3,
            "rpm": 1500,
            "energy_output": 1000
        }
    ]
}

with open("wind_turbine_data.avro", "wb") as f:
    fastavro.writer(f, schema, [data])

# Read data from the file
with open("wind_turbine_data.avro", "rb") as f:
    reader = fastavro.reader(f)
    for record in reader:
        print(record)
