import paho.mqtt.client as mqtt
import pandas as pd
import json
import datetime
from data_cleaning_engine import DataCleaningEngine
# initialize the MQTT client
mqtt_client = mqtt.Client()
mqtt_client.connect("localhost", 1883)
# initialize the data cleaning engine
data_cleaner = DataCleaningEngine()
# define the callback function to be executed when a new message is received
def on_message(client, userdata, msg):
    # decode the message payload from bytes to string
    msg_payload = msg.payload.decode('utf-8')
    # parse the message payload as JSON
    msg_data = json.loads(msg_payload)
    # clean the data using the data cleaning engine
    cleaned_data = data_cleaner.clean_data(msg_payload)
    cleaned_data['rtc'] = datetime.datetime.fromtimestamp(cleaned_data['rtc'] / 10**9)
    # do something with the cleaned data
    print(cleaned_data)
        # append the cleaned data to a CSV file
    with open('cleaned_data.csv', 'a') as f:
        f.write(cleaned_data.to_csv(header=f.tell()==0, index=False))
# set the on_message callback function for the MQTT client
mqtt_client.on_message = on_message
# subscribe to the MQTT topic
mqtt_client.subscribe("wind-turbine-data")
# start the MQTT client loop
mqtt_client.loop_forever()
