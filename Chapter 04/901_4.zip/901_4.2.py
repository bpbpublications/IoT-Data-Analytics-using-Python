import json
# Open the JSON file for reading
with open('turbine_data.json', 'r') as f:
    # Load the JSON data into a Python dictionary
    data = json.load(f)
# Access the values in the dictionary using the keys
header = data['Header']
id = header['ID']
sno = header['SNo']
atype = header['AType']
dtype = header['DType']
uid = header['UID']
ver = header['Ver']
dflag = header['Dflag']
data_values = data['data'][0]
rtc = data_values['rtc']
temp = data_values['temp']
pressure = data_values['pressure']
wind_speed = data_values['wind_speed']
rpm = data_values['rpm']
energy_output = data_values['energy_output']
# Print the values
print('ID:', id)
print('SNo:', sno)
print('AType:', atype)
print('DType:', dtype)
print('UID:', uid)
print('Ver:', ver)
print('Dflag:', dflag)
print('RTC:', rtc)
print('Temp:', temp)
print('Pressure:', pressure)
print('Wind Speed:', wind_speed)
print('RPM:', rpm)
print('Energy Output:', energy_output)
