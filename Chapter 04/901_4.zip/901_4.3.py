import xml.etree.ElementTree as ET

# Parse the XML file and get the root element
tree = ET.parse('xml_data.xml')
root = tree.getroot()

# Retrieve the values for the "temperature" and "humidity" elements
temperature = root.find('temperature').text
humidity = root.find('humidity').text

# Print the values for the "temperature" and "humidity" elements
print("Temperature: " + temperature)
print("Humidity: " + humidity)
