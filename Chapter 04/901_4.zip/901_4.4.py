import xml.etree.ElementTree as ET
# Open the XML file for reading
with open('turbine_data.xml', 'r') as f:
    # Parse the XML data
    tree = ET.parse(f)
    root = tree.getroot()
# Access the values in the XML tree using the tag names
header = root.find('Header')
id = header.find('ID').text
sno = header.find('SNo').text
atype = header.find('AType').text
dtype = header.find('DType').text
uid = header.find('UID').text
ver = header.find('Ver').text
dflag = header.find('Dflag').text
data_values = root.find('data').find('entry')
rtc = data_values.find('rtc').text
temp = data_values.find('temp').text
pressure = data_values.find('pressure').text
wind_speed = data_values.find('wind_speed').text
rpm = data_values.find('rpm').text
energy_output = data_values.find('energy_output').text
# Print the values
print('ID:', id)
print('SNo:', sno)
print('AType:', atype)
print('DType:', dtype)
print('UID:', uid)
print('Ver:', ver)
print('Dflag:', dflag)
print('RTC:', rtc)
print('Temp:', temp)
print('Pressure:', pressure)
print('Wind Speed:', wind_speed)
print('RPM:', rpm)
print('Energy Output:', energy_output)
