import sys
from google.protobuf.json_format import MessageToJson
import turbine_data_pb2
import json

# Define the protobuf message
turbine_data = turbine_data_pb2.TurbineData()

# Parse the binary data
data = b'\n5\n\x08Asset123\x12\nGateway456\x18\x05 \x01*\x07Unit7892\x031.0:\x0b3;1;1;1;100\x12!\n\n1646110800\x1533\xcbA\x1d\x00P}D%\xcd\xccDA(\xdc\x0b0\xe8\x07'
turbine_data.ParseFromString(data)

#turbine_json = MessageToJson(turbine_data)
#convert string to  object
turbine_json = json.loads(MessageToJson(turbine_data))
print(type(turbine_json))
# Print the decoded protobuf data in JSON format
print(MessageToJson(turbine_data))
header = turbine_json["header"]
print('ID:', header['ID'])
print('SNo:', header['SNo'])
print('AType:', header['AType'])
print('DType:', header['DType'])
print('UID:', header['UID'])
print('Ver:', header['Ver'])
print('Dflag:', header['Dflag'])

turbine_data = turbine_json['data'][0]
print('rtc:', turbine_data['rtc'])
print('temp:', turbine_data['temp'])
print('pressure:', turbine_data['pressure'])
print('wind_speed:', turbine_data['windSpeed'])
print('rpm:', turbine_data['rpm'])
print('energy_output:', turbine_data['energyOutput'])
