import cbor

# JSON data to be serialized
data = {
    "temperature": 23.5,
    "humidity": 60.2
}

# Serialize data in CBOR format
serialized_data = cbor.dumps(data)

# Print serialized data
print("Serialized data: ", serialized_data)

# Deserialize data from CBOR format
deserialized_data = cbor.loads(serialized_data)

# Print deserialized data
print("Deserialized data: ", deserialized_data)
