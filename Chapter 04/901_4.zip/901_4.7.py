import protobuf_data_pb2
# Create a SensorData message object
sensor_data = protobuf_data_pb2.SensorData()
# Decode the binary data
binary_data = b'\x0d\x9a\x99\x38\x41\x15\x33\x33\xb3\x40'
sensor_data.ParseFromString(binary_data)
# Print the values of the fields in the message
print("Temperature:", sensor_data.temperature)
print("Humidity:", sensor_data.humidity)
